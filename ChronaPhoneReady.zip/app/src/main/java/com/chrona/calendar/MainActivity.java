package com.chrona.calendar;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.view.View;

public class MainActivity extends Activity {
  private WebView webView;
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().setStatusBarColor(Color.rgb(247,247,250));
    getWindow().setNavigationBarColor(Color.rgb(247,247,250));
    webView = new WebView(this);
    webView.setBackgroundColor(Color.rgb(247,247,250));
    webView.setWebViewClient(new WebViewClient());
    WebSettings s = webView.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    s.setBuiltInZoomControls(false);
    s.setDisplayZoomControls(false);
    webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
    webView.loadUrl("file:///android_asset/index.html");
    setContentView(webView);
  }
  @Override public void onBackPressed() {
    if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
  }
}
